# MODX Extras Reference

Patterns and examples for core extras: pdoTools, MIGX, FormIt, SEO Suite, Image+, Collections, Tagger, Babel.

## Table of Contents
1. [pdoTools](#pdotools)
2. [MIGX](#migx)
3. [FormIt](#formit)
4. [SEO Suite](#seo-suite)
5. [Image+](#image)
6. [ClientConfig](#clientconfig)
7. [Collections](#collections)
8. [Tagger](#tagger)
9. [Babel](#babel)

---

## pdoTools

High-performance alternative to getResources, Wayfinder, and Breadcrumbs.

### pdoResources

#### Basic Listing
```
[[pdoResources?
  &parents=`5`
  &limit=`10`
  &tpl=`tplBlogCard`
]]
```

#### Full Parameters
```
[[pdoResources?
  &parents=`[[*id]]`
  &depth=`2`
  &limit=`12`
  &offset=`0`
  &sortby=`publishedon`
  &sortdir=`DESC`
  &tpl=`tplCard`
  &includeTVs=`heroImage,introText`
  &processTVs=`1`
  &tvPrefix=``
  &where=`{"published":1,"deleted":0}`
  &showHidden=`0`
  &hideContainers=`0`
  &context=`web`
  &idx=`1`
  &first=`1`
  &last=`0`
  &totalVar=`total`
  &tplWrapper=`@INLINE <div class="grid">[[+output]]</div>`
  &wrapIfEmpty=`0`
]]
```

#### Key Parameters
| Parameter | Purpose |
|-----------|---------|
| `&parents` | Parent ID(s), comma-separated |
| `&resources` | Specific resource IDs to include |
| `&depth` | How deep to search (0=unlimited) |
| `&limit` | Max results (0=unlimited) |
| `&offset` | Skip first N results |
| `&sortby` | Field to sort by |
| `&sortdir` | ASC or DESC |
| `&tpl` | Chunk for each item |
| `&includeTVs` | TV names to include |
| `&processTVs` | Process TV values (1/0) |
| `&tvPrefix` | Prefix for TV placeholders |
| `&where` | JSON filter conditions |
| `&showHidden` | Include hidemenu=1 |

#### Available Placeholders in tpl
```
[[+id]]           Resource ID
[[+pagetitle]]    Page title
[[+longtitle]]    Long title
[[+description]]  Description
[[+alias]]        URL slug
[[+content]]      Content
[[+introtext]]    Intro text
[[+menutitle]]    Menu title
[[+link]]         Generated URL
[[+idx]]          Loop index (starts at 1)
[[+first]]        1 if first item
[[+last]]         1 if last item
[[+total]]        Total count
[[+tvName]]       TV value (with tvPrefix=``)
```

#### Sample tpl Chunk (tplBlogCard)
```html
<article class="card [[+first:notempty=`card--featured`]]">
  [[+heroImage:notempty=`
    <img src="[[+heroImage]]" alt="[[+pagetitle]]" loading="lazy">
  `]]
  <div class="card__body">
    <h3><a href="[[+link]]">[[+pagetitle]]</a></h3>
    <p>[[+introtext:ellipsis=`150`]]</p>
    <time datetime="[[+publishedon:date=`%Y-%m-%d`]]">
      [[+publishedon:date=`%B %d, %Y`]]
    </time>
  </div>
</article>
```

### pdoMenu

#### Basic Navigation
```
[[pdoMenu?
  &parents=`0`
  &level=`2`
]]
```

#### Custom Templates
```
[[pdoMenu?
  &parents=`0`
  &level=`2`
  &tplOuter=`@INLINE <nav><ul class="nav">[[+wrapper]]</ul></nav>`
  &tpl=`@INLINE <li><a href="[[+link]]">[[+menutitle]]</a></li>`
  &tplParentRow=`@INLINE <li class="has-dropdown"><a href="[[+link]]">[[+menutitle]]</a>[[+wrapper]]</li>`
  &tplInner=`@INLINE <ul class="dropdown">[[+wrapper]]</ul>`
]]
```

#### Key Parameters
| Parameter | Purpose |
|-----------|---------|
| `&parents` | Starting point (0=top level) |
| `&level` | Depth of menu |
| `&tplOuter` | Wrapper template |
| `&tpl` | Each menu item |
| `&tplParentRow` | Items with children |
| `&tplInner` | Submenu wrapper |
| `&tplHere` | Current page item |
| `&tplParentRowHere` | Current parent item |

#### Critical: `[[+wrapper]]` Placement
The `[[+wrapper]]` placeholder outputs child menus. It MUST appear:
- In `&tplParentRow` - after the link, for dropdown menus
- In `&tplInner` - for the child items

### pdoCrumbs

```
[[pdoCrumbs?
  &showHome=`1`
  &showCurrent=`1`
  &tpl=`@INLINE <li><a href="[[+link]]">[[+menutitle]]</a></li>`
  &tplCurrent=`@INLINE <li aria-current="page">[[+menutitle]]</li>`
  &tplWrapper=`@INLINE <nav aria-label="Breadcrumb"><ol class="breadcrumb">[[+output]]</ol></nav>`
]]
```

### pdoPage (Pagination)

```
[[!pdoPage?
  &element=`pdoResources`
  &parents=`5`
  &limit=`12`
  &tpl=`tplCard`
  &pageVarKey=`page`
  &pageLimit=`5`
  &tplPageWrapper=`@INLINE <nav class="pagination">[[+first]][[+prev]][[+pages]][[+next]][[+last]]</nav>`
]]
```

---

## MIGX

Multi-Items Grid for eXtended functionality - a powerful custom TV input type for creating repeatable, structured data fields. MIGX aggregates multiple fields into a single TV, storing data as JSON. Perfect for FAQs, testimonials, galleries, team members, process steps, and any repeatable content.

### How MIGX Works

1. **Form Tabs**: Define the input form users see when adding/editing items
2. **Grid Columns**: Define the summary view displaying all items
3. **Data Storage**: Items stored as JSON array in a single TV
4. **Frontend Output**: Use `getImageList` snippet to render items

### Creating MIGX TVs

There are two methods to configure MIGX:

#### Method 1: MIGX Configurator CMP (Recommended)
1. Go to **Extras → MIGX** → **MIGX** tab
2. Click **Add Item** to create a new configuration
3. Enter a **Name** (e.g., `faqs`) - this becomes your config reference
4. Set the same name in **Unique MIGX ID** field
5. Configure **Formtabs** tab: Add tabs and fields
6. Configure **Columns** tab: Add grid columns
7. Click **Done** to save
8. Create a TV with Input Type: **migx**
9. In TV Input Options, enter the config name in **Configurations** field
10. Leave Form Tabs and Grid Columns fields **empty** (config handles it)

#### Method 2: Raw JSON in TV
1. Create a TV with Input Type: **migx**
2. In Input Options, enter JSON directly in **Form Tabs** and **Grid Columns** fields
3. Leave **Configurations** field empty

### Form Tabs JSON Structure

```json
[{
  "caption": "Tab Name",
  "fields": [{
    "field": "fieldname",
    "caption": "Field Label",
    "inputTVtype": "text"
  }]
}]
```

#### Form Tabs Field Properties

| Property | Description | Required |
|----------|-------------|----------|
| `field` | Unique field name (becomes placeholder `[[+fieldname]]`) | Yes |
| `caption` | Label shown to user in form | Yes |
| `description` | Help text below field | No |
| `inputTVtype` | TV input type (text, textarea, richtext, image, etc.) | Yes |
| `inputTV` | Name of existing TV to use (alternative to inputTVtype) | No |
| `inputOptionValues` | Options for listbox/checkbox (Format: `Label1==value1||Label2==value2`) | No |
| `default` | Default value for new items | No |
| `sourceFrom` | Media source: `config`, `tv`, or `migx` | No |
| `sources` | Media source configuration | No |
| `configs` | For nested MIGX fields | No |

#### Available inputTVtype Values

| Type | Description |
|------|-------------|
| `text` | Single-line text input |
| `textarea` | Multi-line text (no formatting) |
| `richtext` | Rich text editor (TinyMCE/etc.) |
| `image` | Image browser/upload |
| `file` | File browser/upload |
| `checkbox` | Checkbox(es) |
| `option` | Radio buttons |
| `listbox` | Dropdown select |
| `listbox-multiple` | Multi-select listbox |
| `date` | Date picker |
| `number` | Numeric input |
| `email` | Email input |
| `url` | URL input |
| `imageplus` | Image+ cropping TV |
| `migx` | Nested MIGX (for complex structures) |

### Grid Columns JSON Structure

```json
[{
  "header": "Column Header",
  "dataIndex": "fieldname",
  "width": "100",
  "sortable": "true",
  "renderer": "this.renderImage"
}]
```

#### Grid Column Properties

| Property | Description | Required |
|----------|-------------|----------|
| `header` | Column header text | Yes |
| `dataIndex` | Field name to display (matches `field` in Form Tabs) | Yes |
| `width` | Column width (pixels or relative) | No |
| `sortable` | Enable sorting by clicking header (`true`/`false`) | No |
| `renderer` | Display renderer function | No |
| `editor` | Enable inline editing | No |
| `show_in_grid` | Show/hide column (`1`/`0`) | No |

#### Available Renderers

| Renderer | Description |
|----------|-------------|
| `this.renderImage` | Display image thumbnail |
| `this.renderImageFromHtml` | Extract and render image from HTML |
| `this.renderChunk` | Render using a chunk template |
| `this.renderFirst` | Show first part of `value1:value2` |
| `this.renderSecond` | Show second part of `value1:value2` |
| `this.renderCrossTick` | Show checkmark/X for boolean values |
| `this.renderClickCrossTick` | Clickable checkmark/X toggle |
| `this.renderSwitchStatusOptions` | Status toggle dropdown |
| `this.renderDate` | Format date display |
| `ImagePlus.MIGX_Renderer` | Image+ thumbnail |

#### Inline Editing

Add `editor` property to enable editing directly in the grid:

```json
{
  "header": "Title",
  "dataIndex": "title",
  "width": "200",
  "editor": "this.textEditor"
}
```

Available editors: `this.textEditor`, `this.listboxEditor`

### Complete MIGX TV Examples

#### FAQs

**Form Tabs:**
```json
[{
  "caption": "FAQ Item",
  "fields": [
    {"field": "question", "caption": "Question", "inputTVtype": "text"},
    {"field": "answer", "caption": "Answer", "inputTVtype": "richtext"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "Question", "dataIndex": "question", "width": "200", "sortable": "true"},
  {"header": "Answer", "dataIndex": "answer", "width": "300"}
]
```

#### Testimonials

**Form Tabs:**
```json
[{
  "caption": "Testimonial",
  "fields": [
    {"field": "name", "caption": "Customer Name", "inputTVtype": "text"},
    {"field": "title", "caption": "Title/Company", "inputTVtype": "text"},
    {"field": "quote", "caption": "Quote", "inputTVtype": "textarea"},
    {"field": "rating", "caption": "Rating (1-5)", "inputTVtype": "listbox", 
     "inputOptionValues": "5 Stars==5||4 Stars==4||3 Stars==3||2 Stars==2||1 Star==1"},
    {"field": "photo", "caption": "Photo", "inputTVtype": "image"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "Photo", "dataIndex": "photo", "width": "60", "renderer": "this.renderImage"},
  {"header": "Name", "dataIndex": "name", "width": "120", "sortable": "true"},
  {"header": "Quote", "dataIndex": "quote", "width": "200"},
  {"header": "Rating", "dataIndex": "rating", "width": "60"}
]
```

#### Image Gallery

**Form Tabs:**
```json
[{
  "caption": "Image",
  "fields": [
    {"field": "image", "caption": "Image", "inputTVtype": "image"},
    {"field": "title", "caption": "Title", "inputTVtype": "text"},
    {"field": "caption", "caption": "Caption", "inputTVtype": "textarea"},
    {"field": "alt", "caption": "Alt Text", "inputTVtype": "text"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "Image", "dataIndex": "image", "width": "80", "renderer": "this.renderImage"},
  {"header": "Title", "dataIndex": "title", "width": "150", "sortable": "true", "editor": "this.textEditor"},
  {"header": "Caption", "dataIndex": "caption", "width": "200"}
]
```

#### Team Members

**Form Tabs:**
```json
[{
  "caption": "Info",
  "fields": [
    {"field": "name", "caption": "Name", "inputTVtype": "text"},
    {"field": "position", "caption": "Position/Title", "inputTVtype": "text"},
    {"field": "bio", "caption": "Bio", "inputTVtype": "richtext"},
    {"field": "email", "caption": "Email", "inputTVtype": "email"}
  ]
},
{
  "caption": "Photo & Social",
  "fields": [
    {"field": "photo", "caption": "Photo", "inputTVtype": "image"},
    {"field": "linkedin", "caption": "LinkedIn URL", "inputTVtype": "url"},
    {"field": "twitter", "caption": "Twitter URL", "inputTVtype": "url"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "Photo", "dataIndex": "photo", "width": "60", "renderer": "this.renderImage"},
  {"header": "Name", "dataIndex": "name", "width": "120", "sortable": "true"},
  {"header": "Position", "dataIndex": "position", "width": "150"},
  {"header": "Email", "dataIndex": "email", "width": "150"}
]
```

#### Process Steps (with Icon)

**Form Tabs:**
```json
[{
  "caption": "Step",
  "fields": [
    {"field": "stepNumber", "caption": "Step Number", "inputTVtype": "text"},
    {"field": "icon", "caption": "Icon Class", "inputTVtype": "text", "description": "e.g., fa-check, fa-phone"},
    {"field": "title", "caption": "Title", "inputTVtype": "text"},
    {"field": "description", "caption": "Description", "inputTVtype": "textarea"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "#", "dataIndex": "stepNumber", "width": "40"},
  {"header": "Icon", "dataIndex": "icon", "width": "80"},
  {"header": "Title", "dataIndex": "title", "width": "150", "sortable": "true"},
  {"header": "Description", "dataIndex": "description", "width": "250"}
]
```

#### Pricing Table

**Form Tabs:**
```json
[{
  "caption": "Plan Details",
  "fields": [
    {"field": "name", "caption": "Plan Name", "inputTVtype": "text"},
    {"field": "price", "caption": "Price", "inputTVtype": "text"},
    {"field": "period", "caption": "Period", "inputTVtype": "listbox", 
     "inputOptionValues": "per month==/mo||per year==/yr||one-time=="},
    {"field": "description", "caption": "Description", "inputTVtype": "textarea"},
    {"field": "features", "caption": "Features (one per line)", "inputTVtype": "textarea"},
    {"field": "featured", "caption": "Featured Plan?", "inputTVtype": "checkbox", 
     "inputOptionValues": "Yes==1"},
    {"field": "buttonText", "caption": "Button Text", "inputTVtype": "text", "default": "Get Started"},
    {"field": "buttonUrl", "caption": "Button URL", "inputTVtype": "text"}
  ]
}]
```

**Grid Columns:**
```json
[
  {"header": "Plan", "dataIndex": "name", "width": "120", "sortable": "true"},
  {"header": "Price", "dataIndex": "price", "width": "80"},
  {"header": "Featured", "dataIndex": "featured", "width": "60", "renderer": "this.renderCrossTick"}
]
```

### Multiple Form Types

MIGX supports multiple form configurations for different item types:

```json
[[
  {
    "formname": "image_item",
    "formtabs": [{
      "caption": "Image Item",
      "fields": [
        {"field": "title", "caption": "Title", "inputTVtype": "text"},
        {"field": "image", "caption": "Image", "inputTVtype": "image"}
      ]
    }]
  },
  {
    "formname": "text_item",
    "formtabs": [{
      "caption": "Text Item",
      "fields": [
        {"field": "title", "caption": "Title", "inputTVtype": "text"},
        {"field": "content", "caption": "Content", "inputTVtype": "richtext"}
      ]
    }]
  }
]]
```

When using multiple forms, MIGX adds `MIGX_formname` field automatically. Use it to switch templates:

```
[[getImageList? &tvname=`mixedContent` &tpl=`@FIELD:MIGX_formname`]]
```

### Rendering MIGX Data with getImageList

```
[[getImageList?
  &tvname=`faqs`
  &tpl=`tplFaqItem`
]]
```

#### getImageList Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `&tvname` | Name of MIGX TV | (required) |
| `&tpl` | Chunk template for each item | (required) |
| `&docid` | Resource ID to get TV from | current resource |
| `&value` | Raw JSON string (instead of tvname) | |
| `&limit` | Max items to display | 0 (all) |
| `&offset` | Skip first N items | 0 |
| `&totalVar` | Placeholder for total count | total |
| `&randomize` | Randomize order | 0 |
| `&preselectLimit` | Items shown before randomization | 5 |
| `&where` | JSON filter: `{"active:=":"1"}` | |
| `&sort` | JSON sort: `[{"sortby":"name","sortdir":"ASC"}]` | |
| `&toPlaceholder` | Output to placeholder instead | |
| `&toSeparatePlaceholders` | Prefix for individual placeholders | |
| `&outputSeparator` | String between items | |
| `&wrapperTpl` | Wrapper chunk (use `[[+output]]`) | |

#### Available Placeholders in tpl Chunk

| Placeholder | Description |
|-------------|-------------|
| `[[+fieldname]]` | Any field defined in Form Tabs |
| `[[+idx]]` | Item index (starts at 1) |
| `[[+_first]]` | 1 if first item |
| `[[+_last]]` | 1 if last item |
| `[[+_alt]]` | Alternates 1/0 |
| `[[+total]]` | Total item count |
| `[[+MIGX_id]]` | Unique item ID |
| `[[+MIGX_formname]]` | Form type (if using multiple forms) |

#### Example tpl Chunks

**FAQ Item (tplFaqItem):**
```html
<div class="faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
  <h3 itemprop="name">[[+question]]</h3>
  <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
    <div itemprop="text">[[+answer]]</div>
  </div>
</div>
```

**Testimonial (tplTestimonial):**
```html
<div class="testimonial[[+_alt:eq=`1`:then=` testimonial--alt`]]">
  [[+photo:notempty=`<img src="[[+photo]]" alt="[[+name]]" class="testimonial__photo">`]]
  <blockquote class="testimonial__quote">[[+quote]]</blockquote>
  <cite class="testimonial__cite">
    <strong>[[+name]]</strong>
    [[+title:notempty=`<span>[[+title]]</span>`]]
  </cite>
  [[+rating:notempty=`<div class="testimonial__rating" data-rating="[[+rating]]"></div>`]]
</div>
```

**Gallery Image (tplGalleryImage):**
```html
<figure class="gallery__item">
  <a href="[[+image]]" data-lightbox="gallery">
    [[ImagePlus? &value=`[[+image]]` &options=`w=400&h=300&zc=1`]]
  </a>
  [[+caption:notempty=`<figcaption>[[+caption]]</figcaption>`]]
</figure>
```

**Team Member (tplTeamMember):**
```html
<div class="team-member">
  [[+photo:notempty=`<img src="[[+photo]]" alt="[[+name]]" class="team-member__photo">`]]
  <h3 class="team-member__name">[[+name]]</h3>
  <p class="team-member__position">[[+position]]</p>
  <div class="team-member__bio">[[+bio]]</div>
  <div class="team-member__social">
    [[+linkedin:notempty=`<a href="[[+linkedin]]" target="_blank" rel="noopener">LinkedIn</a>`]]
    [[+twitter:notempty=`<a href="[[+twitter]]" target="_blank" rel="noopener">Twitter</a>`]]
  </div>
</div>
```

### Filtering and Sorting MIGX Data

#### Filter by Field Value
```
[[getImageList?
  &tvname=`testimonials`
  &tpl=`tplTestimonial`
  &where=`{"rating:>=":"4"}`
]]
```

#### Multiple Conditions
```
[[getImageList?
  &tvname=`products`
  &tpl=`tplProduct`
  &where=`{"active:=":"1","featured:=":"1"}`
]]
```

#### Sort by Field
```
[[getImageList?
  &tvname=`team`
  &tpl=`tplTeamMember`
  &sort=`[{"sortby":"name","sortdir":"ASC"}]`
]]
```

#### Numeric Sorting
```
[[getImageList?
  &tvname=`pricing`
  &tpl=`tplPricing`
  &sort=`[{"sortby":"price","sortdir":"ASC","sortmode":"numeric"}]`
]]
```

### Image+ Integration in MIGX

When using Image+ fields inside MIGX:

**Form Tabs:**
```json
[{
  "fields": [
    {
      "field": "image",
      "caption": "Image",
      "inputTVtype": "imageplus",
      "configs": {
        "targetWidth": "800",
        "targetHeight": "600",
        "allowAltTag": "1"
      }
    }
  ]
}]
```

**Grid Columns (show thumbnail):**
```json
[{
  "header": "Image",
  "dataIndex": "image",
  "width": "80",
  "renderer": "ImagePlus.MIGX_Renderer"
}]
```

**In tpl Chunk (use &value, not &tvname):**
```
[[ImagePlus?
  &value=`[[+image]]`
  &type=`tpl`
  &tpl=`tplResponsiveImage`
  &options=`w=400`
]]
```

### Media Source Configuration

To use a specific media source for image fields:

```json
{
  "field": "image",
  "caption": "Image",
  "inputTVtype": "image",
  "sourceFrom": "migx"
}
```

Then assign the MIGX TV to the desired media source in the TV's **Media Sources** tab.

### MIGXdb (Database Records)

MIGX can also manage records in custom database tables instead of storing JSON in a TV. This is useful for:

- Large datasets
- Records shared across resources
- Custom Manager Pages (CMPs)

Configure by setting:
- **Package** and **Classname** for your custom table
- Use `migxLoopCollection` snippet instead of `getImageList`

### Troubleshooting MIGX

| Issue | Solution |
|-------|----------|
| TV shows raw JSON | Ensure output type is set to **default**, not migx |
| Fields not saving | Check field names are unique and valid |
| Images not showing | Verify media source assignment on TV |
| Grid columns empty | Ensure `dataIndex` matches `field` names exactly |
| Configurator not saving | Check for JSON syntax errors |
| Items not displaying | Verify TV is assigned to template |

---

## FormIt

Form processing with validation, hooks, and anti-spam.

### Basic Contact Form

```
[[!FormIt?
  &hooks=`spam,email,redirect`
  &emailTpl=`tplContactEmail`
  &emailTo=`[[++email-main]]`
  &emailSubject=`Website Contact: [[+subject]]`
  &redirectTo=`[[++contact_thanks_page]]`
  &validate=`name:required,
    email:required:email,
    phone:required,
    message:required:minLength=^10^`
  &validationErrorMessage=`Please correct the errors below.`
  &validationErrorBulkTpl=`@INLINE <li>[[+error]]</li>`
]]

<form method="post" action="[[~[[*id]]]]">
  <input type="hidden" name="nospam" value="">
  
  <label for="name">Name *</label>
  <input type="text" name="name" id="name" value="[[+fi.name]]">
  <span class="error">[[+fi.error.name]]</span>
  
  <label for="email">Email *</label>
  <input type="email" name="email" id="email" value="[[+fi.email]]">
  <span class="error">[[+fi.error.email]]</span>
  
  <label for="phone">Phone *</label>
  <input type="tel" name="phone" id="phone" value="[[+fi.phone]]">
  <span class="error">[[+fi.error.phone]]</span>
  
  <label for="message">Message *</label>
  <textarea name="message" id="message">[[+fi.message]]</textarea>
  <span class="error">[[+fi.error.message]]</span>
  
  <button type="submit">Send Message</button>
</form>
```

### Email Template (tplContactEmail)
```html
<p>New contact form submission:</p>
<table>
  <tr><td><strong>Name:</strong></td><td>[[+name]]</td></tr>
  <tr><td><strong>Email:</strong></td><td>[[+email]]</td></tr>
  <tr><td><strong>Phone:</strong></td><td>[[+phone]]</td></tr>
  <tr><td><strong>Message:</strong></td><td>[[+message]]</td></tr>
</table>
<p>Submitted: [[+date:date=`%Y-%m-%d %H:%M`]]</p>
```

### Validation Options
```
required              Field required
email                 Valid email
minLength=^N^         Min characters
maxLength=^N^         Max characters
minValue=^N^          Min numeric value
maxValue=^N^          Max numeric value
contains=^str^        Must contain string
regexp=^pattern^      Regex match
```

### Common Hooks
| Hook | Purpose |
|------|---------|
| `spam` | Honeypot spam check |
| `email` | Send email |
| `redirect` | Redirect after success |
| `recaptchav3` | Google reCAPTCHA v3 |
| `FormItSaveForm` | Save to database |
| `FormItAutoResponder` | Send confirmation |

### File Uploads
```
[[!FormIt?
  &hooks=`FormItSaveForm,email,redirect`
  &allowFiles=`1`
  &attachFilesToEmail=`1`
]]

<input type="file" name="attachment" accept=".pdf,.doc,.docx">
```

---

## SEO Suite

Meta fields, redirects, and sitemap management.

### Available Fields
- SEO Title (seoTitle)
- Meta Description (metaDescription)
- Canonical URL
- Robots (index/noindex, follow/nofollow)
- Open Graph fields
- Twitter Card fields

### In Templates
```html
<title>[[*seoTitle:default=`[[*pagetitle]] | [[++brand]]`]]</title>
<meta name="description" content="[[*metaDescription:default=`[[*description]]`]]">
```

### Redirect Management
When changing aliases, SEO Suite prompts to create 301 redirects automatically.

---

## Image+

Advanced image cropping TV with visual editor. Requires pThumb as cropping engine.

### Creating Image+ TVs

1. Create TV in Manager
2. Input Type: **Image+** (select from dropdown)
3. Output Type: **Image+** (for direct URL output) or **default** (for snippet processing)
4. Configure Input Options (see below)

### TV Input Options

| Option | Type | Description |
|--------|------|-------------|
| Target Width | integer | Minimum width constraint |
| Target Height | integer | Minimum height constraint |
| Target Aspect Ratio | float | Constrain crop ratio (ignored if both width AND height set) |
| Show Alt Tag Field | yes/no | Enable alt text input |
| Show Caption Field | yes/no | Enable caption input |
| Show Credits Field | yes/no | Enable credits input |

#### Aspect Ratio Behavior
- **Both Target Width AND Height set**: Aspect ratio is calculated automatically (width ÷ height)
- **Only one dimension set**: No aspect ratio constraint unless Target Aspect Ratio specified
- **Target Aspect Ratio**: Float value = width ÷ height (e.g., 1600÷1000 = **1.6**)

#### Calculating Aspect Ratio
```
16:9  → 1920 ÷ 1080 = 1.777...
4:3   → 800 ÷ 600   = 1.333...
1:1   → 400 ÷ 400   = 1.0
3:4   → 600 ÷ 800   = 0.75
```

### TV Output Options

| Option | Description |
|--------|-------------|
| Additional phpThumb Parameters | Extra params for thumbnail generation |
| Output Chunk | Chunk to render TV output (enables placeholders) |
| Generate Thumb URL | **Must be Yes** if using `[[+url]]` or no output chunk |

⚠️ **Critical**: If "Generate Thumb URL" is **No** and no output chunk is specified, the original uncropped image path is returned.

### ImagePlus Snippet

The snippet provides flexible output options beyond TV output.

#### Snippet Properties
| Property | Description | Default |
|----------|-------------|---------|
| `&tvname` | Name of Image+ TV | (required unless using &value) |
| `&docid` | Resource ID to get TV from | current resource |
| `&value` | Raw JSON value (for MIGX fields) | - |
| `&options` | Extended phpThumb options | - |
| `&type` | Output type: `check`, `tpl`, `thumb` | - |
| `&tpl` | Template chunk for output | `ImagePlus.image` |

#### Type Values
| Type | Output |
|------|--------|
| `check` | Returns "image" if TV has image, "noimage" if empty |
| `tpl` | Returns parsed template chunk with placeholders |
| `thumb` | Returns thumbnail URL only |
| (none) | Returns thumbnail URL (same as thumb) |

#### phpThumb Options
```
w=800        Width in pixels
h=450        Height in pixels
zc=1         Zoom crop (1=crop to fit)
q=85         Quality (1-100)
aoe=1        Allow output enlargement
f=webp       Output format
```

### Usage Patterns

#### Basic Snippet Call (returns URL)
```
[[ImagePlus?
  &tvname=`heroImage`
  &options=`w=800`
]]
```

#### With Template Chunk
```
[[ImagePlus?
  &tvname=`heroImage`
  &type=`tpl`
  &tpl=`tplHeroImage`
  &options=`w=1200`
]]
```

#### In pdoResources Template Chunk
**Critical**: Must include `&docid=`[[+id]]`` to get correct resource's image:
```
[[ImagePlus?
  &tvname=`heroImage`
  &docid=`[[+id]]`
  &type=`tpl`
  &tpl=`tplBlogImage`
]]
```

#### Check if Image Exists
```
[[ImagePlus?
  &tvname=`heroImage`
  &type=`check`
]]
```
Returns: `image` or `noimage`

#### In MIGX (using &value)
When Image+ is used inside MIGX, use `&value` instead of `&tvname`:
```
[[ImagePlus?
  &value=`[[+image]]`
  &type=`tpl`
  &tpl=`tplGalleryImage`
  &options=`w=600`
]]
```

### Template Chunk Placeholders

| Placeholder | Description |
|-------------|-------------|
| `[[+url]]` | Cropped/resized image URL |
| `[[+alt]]` | Alt text (if enabled) |
| `[[+caption]]` | Caption text (if enabled) |
| `[[+credits]]` | Credits text (if enabled) |
| `[[+width]]` | Minimal width of thumbnail |
| `[[+height]]` | Minimal height of thumbnail |
| `[[+source.src]]` | Full server path to original image |
| `[[+source.width]]` | Original image width |
| `[[+source.height]]` | Original image height |
| `[[+crop.width]]` | Crop area width |
| `[[+crop.height]]` | Crop area height |
| `[[+crop.x]]` | Crop X position |
| `[[+crop.y]]` | Crop Y position |
| `[[+crop.options]]` | pThumb crop options string |
| `[[+options]]` | Full pThumb options string |

### Example Template Chunks

#### Simple Image (tplSimpleImage)
```html
<img src="[[+url]]" alt="[[+alt]]" loading="lazy">
```

#### Responsive Image (tplResponsiveImage)
```html
<picture>
  <source srcset="[[+source.src:pthumb=`w=1200`]] 1200w,
                  [[+source.src:pthumb=`w=800`]] 800w,
                  [[+source.src:pthumb=`w=400`]] 400w"
          sizes="(min-width: 800px) 800px, 100vw">
  <img src="[[+url]]" alt="[[+alt]]" loading="lazy">
</picture>
```

#### With Cropped Responsive Versions
```html
<picture>
  <source media="(min-width: 36em)" 
          srcset="[[+source.src:pthumb=`w=1024`]] 1024w,
                  [[+source.src:pthumb=`w=640`]] 640w"
          sizes="33.3vw">
  <source srcset="[[+source.src:pthumb=`[[+crop.options]]&w=640`]] 2x,
                  [[+source.src:pthumb=`[[+crop.options]]&w=320`]] 1x">
  <img src="[[+url]]" alt="[[+alt]]">
</picture>
```

### MIGX Integration

#### Form Tabs Configuration
```json
[{
  "fields": [
    {
      "field": "image",
      "caption": "Image",
      "inputTVtype": "imageplus",
      "configs": {
        "targetWidth": "800",
        "targetHeight": "450",
        "allowAltTag": "1"
      }
    }
  ]
}]
```

#### Grid Columns (show thumbnail)
```json
[{
  "header": "Image",
  "dataIndex": "image",
  "renderer": "ImagePlus.MIGX_Renderer"
}]
```

### Collections Integration
Set column renderer to `ImagePlus.MIGX_Renderer` to show thumbnails in grid.

### System Settings

Override TV input options globally or per-TV:

| Setting | Description |
|---------|-------------|
| `imageplus.target_width` | Global target width |
| `imageplus.target_height` | Global target height |
| `imageplus.target_ratio` | Global aspect ratio |
| `imageplus.allow_alt_tag` | Show alt field globally |
| `imageplus.allow_caption` | Show caption field globally |
| `imageplus.allow_credits` | Show credits field globally |
| `imageplus.{tvname}.target_width` | Per-TV target width |

Settings priority: TV-specific context → TV-specific system → global context → global system

### Troubleshooting

| Issue | Solution |
|-------|----------|
| Returns original path, not thumbnail | Set "Generate Thumb URL" to **Yes** in TV Output Options |
| Blank output | Check TV name matches exactly (case-sensitive) |
| Wrong image in pdoResources | Add `&docid=`[[+id]]`` to snippet call |
| MIGX shows JSON string | Use `&value` parameter instead of `&tvname` |
| Alt/caption not showing | Enable fields in TV Input Options AND use output chunk/tpl |

### Common Aspect Ratios

| Use Case | Ratio | Float Value | Example Size |
|----------|-------|-------------|--------------|
| Hero/Banner | 16:9 | 1.778 | 1920×1080 |
| Blog Featured | 16:9 | 1.778 | 1200×675 |
| Landscape | 4:3 | 1.333 | 800×600 |
| Square/Avatar | 1:1 | 1.0 | 400×400 |
| Portrait | 3:4 | 0.75 | 600×800 |
| Cinematic | 21:9 | 2.333 | 2560×1080 |

Use the **Float Value** in the "Target Aspect Ratio" field.

---

## ClientConfig

Centralized site settings editable by non-developers.

### Accessing Settings
```
[[++settingKey]]
```

### Setting Groups (Standard LSB Setup)
1. **Company Information** - brand, legal-name, tagline, site-url
2. **Contact & NAP** - phone-main, email-main, address-*, geo-*, hours-json
3. **Social Links** - social-facebook, social-instagram, etc.
4. **Tracking & Analytics** - ga4-measurement-id, gtm-id, facebook-pixel-id
5. **Schema & SEO** - business-type, price-range, review ratings
6. **Service Areas** - base-city, service-cities, service-counties, radius-miles
7. **Branding** - logo-url, primary-color, secondary-color
8. **Site Structure & IDs** - services_root, blog_root, contact_page

### Conditional Usage
```
[[++gtm-id:notempty=`
  <!-- Google Tag Manager -->
  <script>...</script>
`]]

[[++social-facebook:notempty=`
  <a href="[[++social-facebook]]" aria-label="Facebook">
    <svg>...</svg>
  </a>
`]]
```

### JSON Settings (hours-json)
```
[[++hours-json]]
```
Outputs:
```json
[{"dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday"],"opens":"08:00","closes":"17:00"}]
```
Used in schema markup snippets to generate OpeningHoursSpecification.

---

## Collections

Grid-based management for child resources. Ideal for blogs, products, news, and any content type with many children.

### Overview

Collections adds a `CollectionContainer` resource class that:
- Hides direct children from the Resource Tree
- Displays children in a sortable, filterable grid view
- Supports drag-and-drop sorting
- Allows bulk actions on multiple resources
- Provides customizable column views

### Setting Up a Collection

1. Create or edit a Resource
2. Go to Settings tab → Resource Type
3. Change to `CollectionContainer`
4. Save - children now appear in grid under "Children" tab

### Collection Views (CMP)

Configure views at: **Extras → Collection Views**

| Setting | Purpose |
|---------|---------|
| Page size | Default items per page |
| Sort field | Default sort column |
| Sort dir | ASC or DESC |
| Allow bulk actions | Enable multi-select checkboxes |
| Allow drag & drop | Enable manual sorting |
| Default children's template | Auto-assign template to new children |

### Grid Columns

Add columns showing:
- Standard resource fields (`pagetitle`, `alias`, `publishedon`)
- Template Variables (prefix with `tv_`: `tv_heroImage`)
- Tagger groups (prefix with `tagger_`: `tagger_categories`)

### Collections + Image+ Integration

To show Image+ thumbnails in Collections grid:
1. Add column with TV name (e.g., `heroImage`)
2. Set Renderer to `ImagePlus.MIGX_Renderer`

### Selections (Curated Lists)

`SelectionContainer` creates curated resource lists without duplicating content:
- Add existing resources from anywhere in the tree
- Maintains separate menuindex for custom ordering
- Use `getSelections` snippet to output

```
[[getSelections?
  &container=`15`
  &tpl=`tplSelectionCard`
  &sortby=`menuindex`
]]
```

### Best Practices

- Use Collections for any container with 10+ children
- Configure default template for consistent child creation
- Add TV columns for quick content overview
- Enable bulk actions for efficient management

---

## Tagger

Robust tagging and taxonomy system for categorizing resources.

### Overview

Tagger provides:
- Tag Groups (categories, topics, types, etc.)
- Tags within each group
- Resource-to-tag assignments
- Snippets for displaying and filtering by tags

### Creating Tag Groups

**Extras → Tagger → Groups → Create Group**

| Setting | Purpose |
|---------|---------|
| Name | Display name |
| Alias | URL-friendly identifier |
| Field type | `tagger-combo-tag` (free-form) or `tagger-field-tags` (autocomplete) |
| Allow new tags | Let editors create tags on-the-fly |
| Remove unused | Auto-delete tags with no resources |
| Show for templates | Limit to specific templates |

### Assigning Tags to Resources

Tags appear in the Resource editor based on "Show for templates" setting. Editors can:
- Select from existing tags (dropdown)
- Type to search/filter
- Create new tags (if allowed)

### TaggerGetTags Snippet

Display tags for resources:

```
[[!TaggerGetTags?
  &resources=`[[*id]]`
  &groups=`categories`
  &rowTpl=`tpl.TagLink`
  &separator=`, `
]]
```

#### tpl.TagLink Chunk
```html
<a href="[[+uri]]" class="tag">[[+tag]]</a>
```

#### Available Placeholders
```
[[+id]]           Tag ID
[[+tag]]          Tag name
[[+alias]]        Tag alias (URL-friendly)
[[+group]]        Group ID
[[+group_name]]   Group name
[[+group_alias]]  Group alias
[[+uri]]          Generated URL to tag listing
[[+idx]]          Loop index
[[+active]]       1 if currently active tag
```

### TaggerGetResourcesWhere Snippet

Filter pdoResources/getResources by tags:

```
[[!pdoResources?
  &parents=`5`
  &where=`[[!TaggerGetResourcesWhere? &groups=`categories`]]`
  &tpl=`tpl.BlogCard`
]]
```

The snippet reads `$_GET` parameters to filter by selected tags.

### Tag Listing Page Pattern

**Step 1**: Create tag links pointing to listing page

```
[[!TaggerGetTags?
  &groups=`categories`
  &target=`10`
  &rowTpl=`tpl.TagLink`
]]
```

**Step 2**: On listing page (ID 10), filter by active tag

```
[[!pdoResources?
  &parents=`5`
  &where=`[[!TaggerGetResourcesWhere]]`
  &tpl=`tpl.BlogCard`
  &limit=`12`
]]
```

### TaggerGetCurrentTag Snippet

Display currently active tag(s):

```
[[!TaggerGetCurrentTag?
  &tagTpl=`@INLINE [[+label]]`
  &groupTpl=`@INLINE <li>[[+name]]: [[+tags]]</li>`
  &outTpl=`@INLINE <ul>[[+groups]]</ul>`
]]
```

### Common Configurations

#### Blog Categories
```
Group: Categories
Alias: categories
Field type: tagger-combo-tag
Allow new: No (admin-controlled)
Templates: Blog Post
```

#### Content Tags (Free-form)
```
Group: Tags
Alias: tags
Field type: tagger-field-tags
Allow new: Yes
Remove unused: Yes
Templates: Blog Post, Article
```

#### Product Types
```
Group: Product Type
Alias: product-type
Field type: tagger-combo-tag
Allow new: No
Templates: Product
```

### Collections + Tagger Integration

Show tags in Collections grid:
1. Add column with Name: `tagger_groupalias` (e.g., `tagger_categories`)
2. Tags display automatically

### Best Practices

- Use descriptive group aliases for clean URLs
- Limit "Allow new tags" to prevent tag sprawl
- Enable "Remove unused" for user-generated tags
- Create separate groups for different taxonomy types
- Use `&target` parameter to control tag link destinations

---

## Babel

Multilingual website management using MODX contexts. Babel maintains links between translated resources and synchronizes TVs across languages.

### Overview

Babel enables:
- **Translation Links**: Connect resources across language contexts
- **Babel Box**: Manager UI to switch between translations and create new ones
- **TV Synchronization**: Keep selected TVs identical across all translations
- **Context Groups**: Manage multiple multilingual sites in one MODX instance

### Requirements

- MODX Revolution 2.8+
- PHP 7.2+
- Separate context for each language

### Installation & Setup

#### 1. Create Language Contexts

For each language, create a context with these settings:

| Setting | Example (German) | Example (French) |
|---------|------------------|------------------|
| Context Key | `de` | `fr` |
| `cultureKey` | `de` | `fr` |
| `site_url` | `https://example.com/de/` | `https://example.com/fr/` |
| `base_url` | `/de/` | `/fr/` |
| `site_start` | German homepage ID | French homepage ID |
| `error_page` | German 404 ID | French 404 ID |

#### 2. Configure Babel System Settings

After installation, set these in System → Settings → babel namespace:

| Setting | Description | Example |
|---------|-------------|---------|
| `babel.contextKeys` | Comma-separated context keys | `web,de,fr,es` |
| `babel.syncTvs` | TV IDs to synchronize | `1,2,3` |
| `babel.babelTvName` | TV storing translation links | `babelLanguageLinks` |

**Multiple Site Groups** (semicolon-separated):
```
babel.contextKeys: web,de,fr;site2_en,site2_de
```

#### 3. Context Routing

Use a routing extra like **LangRouter** or **xRouting**, or create a custom plugin:

```php
<?php
// Plugin on OnHandleRequest event
if ($modx->context->get('key') != 'mgr') {
    switch ($_REQUEST['cultureKey']) {
        case 'de':
            $modx->switchContext('de');
            break;
        case 'fr':
            $modx->switchContext('fr');
            break;
        default:
            $modx->switchContext('web');
    }
    unset($_GET['cultureKey']);
}
```

### Using the Babel Box

When editing a resource, the Babel Box appears at the top with buttons for each language:

| Button Color | Meaning |
|--------------|---------|
| **Black** | Current language being edited |
| **Green** | Translation exists (click to switch) |
| **Gray** | No translation yet (click to create) |

**Actions:**
- **Create Translation**: Click gray button → Babel copies resource to that context
- **Link Existing**: Use the Babel CMP to manually link resources
- **Unlink**: Hover green button → "Unlink translation" option

### BabelLinks Snippet

Generates language switcher links for the frontend.

#### Basic Usage
```
[[BabelLinks]]
```

#### With Custom Template
```
[[BabelLinks?
  &tpl=`tplLanguageLink`
  &activeCls=`active`
  &showCurrent=`1`
]]
```

#### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `&tpl` | (built-in) | Chunk for each link |
| `&activeCls` | `active` | CSS class for current language |
| `&showCurrent` | `1` | Show link to current language |
| `&showUnpublished` | `0` | Include unpublished translations |
| `&resourceId` | current | Resource ID to get translations for |
| `&includeUnlinked` | `0` | Show contexts without translations |
| `&toArray` | `0` | Return as array for pdoTools |
| `&toPlaceholder` | | Output to placeholder instead |

#### Available Placeholders in tpl

```
[[+cultureKey]]      Language code (en, de, fr)
[[+url]]             Full URL to translation
[[+active]]          "active" class if current language
[[+id]]              Resource ID of translation
```

#### tpl Chunk Example (tplLanguageLink)
```html
<li class="lang-item [[+active]]">
  <a href="[[+url]]" class="[[+cultureKey]]" hreflang="[[+cultureKey]]">
    [[%babel.language_[[+cultureKey]]? &namespace=`babel` &topic=`default`]]
  </a>
</li>
```

#### Complete Language Switcher
```html
<nav class="language-switcher" aria-label="Language">
  <ul>
    [[BabelLinks?
      &tpl=`@INLINE <li><a href="[[+url]]" class="[[+cultureKey]] [[+active]]" hreflang="[[+cultureKey]]">[[+cultureKey:uppercase]]</a></li>`
      &activeCls=`current`
      &showCurrent=`1`
    ]]
  </ul>
</nav>
```

### BabelTranslation Snippet

Returns the resource ID of a translation in a specific context.

#### Basic Usage
```
[[BabelTranslation? &contextKey=`de`]]
```

Returns: Resource ID of the German translation (or empty if none).

#### Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `&contextKey` | | Target context key (required) |
| `&resourceId` | current | Source resource ID |
| `&showUnpublished` | `0` | Return unpublished translations |

#### Use Cases

**Link to specific translation:**
```html
<a href="[[~[[BabelTranslation? &contextKey=`de`]]]]">Auf Deutsch lesen</a>
```

**Conditional content based on translation existence:**
```
[[BabelTranslation? &contextKey=`de`:notempty=`
  <a href="[[~[[BabelTranslation? &contextKey=`de`]]]]">German version available</a>
`]]
```

**Get translation in pdoResources tpl:**
```
[[BabelTranslation? &contextKey=`de` &resourceId=`[[+id]]`]]
```

### hreflang Tags for SEO

Add proper hreflang tags in your template `<head>`:

```html
[[BabelLinks?
  &tpl=`@INLINE <link rel="alternate" hreflang="[[+cultureKey]]" href="[[+url]]">`
  &showCurrent=`1`
]]
<link rel="alternate" hreflang="x-default" href="[[~[[*id]]? &scheme=`full`]]">
```

### TV Synchronization

Babel can automatically sync TV values across all translations. Useful for:
- Images that should be the same in all languages
- Dates, prices, SKUs
- Layout/display settings

**Configure in System Settings:**
```
babel.syncTvs: 5,8,12
```
(Comma-separated list of TV IDs)

When you save a resource, synced TVs are copied to all linked translations.

### Common Patterns

#### Language-Aware Navigation
```
[[pdoMenu?
  &parents=`[[BabelTranslation? &contextKey=`[[++cultureKey]]` &resourceId=`[[++nav-root]]`]]`
  &level=`2`
  &tpl=`nav.tpl.MainLink`
]]
```

#### Linking Static Resources Across Languages
```html
<!-- In a chunk that needs to link to Contact page (ID 5 in English) -->
<a href="[[~[[BabelTranslation? &contextKey=`[[++cultureKey]]` &resourceId=`5`]]]]">
  [[%contact? &namespace=`site`]]
</a>
```

#### Check if Translation Exists
```
[[!BabelTranslation? &contextKey=`de`:empty=`
  <!-- No German translation -->
`:else=`
  <!-- German translation exists -->
`]]
```

### Babel CMP (Custom Manager Page)

Access via **Extras → Babel** to:
- View all translation links
- Manually link/unlink resources
- Find orphaned resources (no translations)
- Bulk operations on translation links

### Best Practices

1. **Plan context structure first** - Set up all contexts before installing Babel
2. **Use consistent aliases** - Keep URL slugs similar across languages when possible
3. **Sync sparingly** - Only sync TVs that truly need to be identical
4. **Test routing thoroughly** - Ensure context switching works before content entry
5. **Create base resources first** - Build site structure in primary language, then translate
6. **Use lexicons for static text** - Don't hardcode strings; use `[[%key]]` tags
7. **Set hreflang tags** - Critical for SEO on multilingual sites

### Troubleshooting

| Issue | Solution |
|-------|----------|
| Babel Box not showing | Check `babel.contextKeys` includes all contexts |
| Links go to homepage | Verify context `site_url` and `base_url` settings |
| Wrong language displays | Check context routing plugin/extra |
| TVs not syncing | Verify TV IDs in `babel.syncTvs` are correct |
| Translations not linking | Use Babel CMP to manually create links |

### Resources

- **Package**: https://extras.modx.com/package/babel
- **Documentation**: https://mikrobi.github.io/babel/
- **GitHub**: https://github.com/mikrobi/babel
